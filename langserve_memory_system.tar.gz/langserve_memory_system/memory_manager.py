"""Abstraction layer for storing and retrieving chat history.

This module defines a ``MemoryManager`` class that can persist and
recover arbitrary conversation data keyed by a ``session_id``.  The
manager supports two backend storage engines: a local SQLite
database or a ChromaDB collection.  The backend is chosen at
construction time based on the ``MEMORY_BACKEND`` environment
variable (``sqlite`` by default).

Chroma is a simple vector database often used to store embeddings
associated with pieces of text.  In this example we use it purely as
a persistent document store keyed by ID; no similarity search is
performed.  For more advanced applications you could store message
embeddings alongside the raw JSON string and build retrievers.

Example usage
-------------

```python
from memory_manager import MemoryManager

manager = MemoryManager(backend="sqlite", sqlite_path="memory.db")
manager.save("chat-123", messages)
history = manager.load("chat-123")
```
```
"""

from __future__ import annotations

import json
import os
from typing import Any, List, Optional

try:
    # Chroma is optional; import only if available
    from chromadb import PersistentClient
except ImportError:
    PersistentClient = None  # type: ignore

import sqlite3


class MemoryManager:
    """Manage conversation memory using either SQLite or ChromaDB.

    Parameters
    ----------
    backend : str, optional
        Name of the backend to use: ``"sqlite"`` (default) or ``"chroma"``.
    sqlite_path : str, optional
        File path for the SQLite database when using the ``sqlite`` backend.
    chroma_path : str, optional
        Directory for persisting Chroma collections when using the
        ``chroma`` backend.

    Notes
    -----
    The ``chroma`` backend relies on the ``chromadb`` package.  If it is not
    installed and you attempt to use the ``chroma`` backend an ImportError
    will be raised.
    """

    def __init__(
        self,
        backend: str = "sqlite",
        sqlite_path: str = "memory.db",
        chroma_path: str = "chromadb_data",
    ) -> None:
        backend = backend.lower()
        self.backend = backend
        if backend not in {"sqlite", "chroma"}:
            raise ValueError("backend must be either 'sqlite' or 'chroma'")
        if backend == "sqlite":
            # Initialise SQLite connection
            self.conn = sqlite3.connect(sqlite_path, check_same_thread=False)
            self._create_sqlite_table()
        else:
            # Ensure chromadb is available
            if PersistentClient is None:
                raise ImportError(
                    "The chromadb package is required for the 'chroma' backend."
                )
            # Initialise Chroma persistent client and collection
            self.chroma_client = PersistentClient(path=chroma_path)
            self.collection = self.chroma_client.get_or_create_collection(name="memories")

    def _create_sqlite_table(self) -> None:
        """Create the SQLite table if it does not exist."""
        with self.conn:
            self.conn.execute(
                """
                CREATE TABLE IF NOT EXISTS memories (
                    session_id TEXT PRIMARY KEY,
                    data TEXT NOT NULL
                )
                """
            )

    def save(self, session_id: str, messages: List[Any]) -> None:
        """Store a list of messages for a given session.

        Parameters
        ----------
        session_id : str
            Unique identifier for the conversation thread.
        messages : list
            Arbitrary JSON‑serialisable Python object representing the chat
            history.  Typically a list of dictionaries with ``role`` and
            ``content`` keys.
        """
        # Serialise the messages to JSON once.  This ensures both
        # backends store the exact same representation.
        data_json = json.dumps(messages)
        if self.backend == "sqlite":
            with self.conn:
                self.conn.execute(
                    """
                    INSERT INTO memories (session_id, data)
                    VALUES (?, ?)
                    ON CONFLICT(session_id) DO UPDATE SET data = excluded.data
                    """,
                    (session_id, data_json),
                )
        else:
            # Using Chroma as a simple key‑value store.  If a document
            # already exists with this ID it must be removed before
            # re‑adding, otherwise an error will be raised.
            try:
                # Delete previous entry if it exists
                self.collection.delete(ids=[session_id])
            except Exception:
                # Delete may throw if the document does not exist; ignore
                pass
            self.collection.add(documents=[data_json], ids=[session_id])

    def load(self, session_id: str) -> Optional[List[Any]]:
        """Retrieve the stored messages for a given session.

        Parameters
        ----------
        session_id : str
            Unique identifier for the conversation thread.

        Returns
        -------
        list | None
            The list of messages previously saved for this session, or
            ``None`` if the session does not exist.
        """
        if self.backend == "sqlite":
            cursor = self.conn.execute(
                "SELECT data FROM memories WHERE session_id = ?", (session_id,)
            )
            row = cursor.fetchone()
            if row is None:
                return None
            return json.loads(row[0])
        else:
            result = self.collection.get(ids=[session_id])
            # Chroma returns a dictionary with keys 'ids' and 'documents'
            docs = result.get("documents")
            if not docs:
                return None
            return json.loads(docs[0])