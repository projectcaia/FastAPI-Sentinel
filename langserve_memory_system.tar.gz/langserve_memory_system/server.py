"""FastAPI server for the LangServe memory system.

This script boots a small FastAPI application that provides two
endpoints for saving and loading chat history.  Under the hood it
delegates all persistence to the :class:`MemoryManager` class, which
supports either a SQLite or Chroma backend.  The choice of backend
and file locations are configurable via environment variables (see
``.env.example``).

For demonstration purposes the server also mounts a trivial
``echo`` endpoint powered by LangServe to illustrate how LangChain
runnables can be exposed alongside custom routes.  Clients can
`POST` to ``/echo/invoke`` with a JSON body containing an ``input``
field to receive a simple echoed response.

To start the server locally, run:

```
uvicorn server:app --reload --host 0.0.0.0 --port 8000
```

If the required dependencies are installed, the OpenAPI documentation
will be available at ``/docs``.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

from memory_manager import MemoryManager

# Optionally import LangServe to expose runnables as REST endpoints.
# If LangServe is not installed the import will fail gracefully and
# custom endpoints will still function.  Clients will simply not
# receive the demonstration endpoint.
try:
    from langserve import add_routes
    from langchain_core.runnables import RunnableLambda
except ImportError:
    add_routes = None  # type: ignore
    RunnableLambda = None  # type: ignore

# Load environment variables from .env
load_dotenv()

# Determine backend and storage paths from the environment.  Fall back
# to defaults if variables are unset.
backend = os.getenv("MEMORY_BACKEND", "sqlite")
sqlite_path = os.getenv("SQLITE_DB_PATH", "memory.db")
chroma_dir = os.getenv("CHROMA_PERSIST_DIRECTORY", "chromadb_data")

# Instantiate the memory manager.  If the chroma backend is selected
# but chromadb is not installed this will raise an ImportError.
memory_manager = MemoryManager(
    backend=backend,
    sqlite_path=sqlite_path,
    chroma_path=chroma_dir,
)

app = FastAPI(
    title="LangServe Memory Server",
    description=(
        "Expose endpoints to save and load chat history using either "
        "SQLite or Chroma.  Includes a sample LangServe runnable."
    ),
    version="0.1.0",
)

# Allow cross‑origin requests during development.  Modify for
# production deployments as appropriate.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class SaveRequest(BaseModel):
    """Pydantic model for the /memory/save request body."""

    session_id: str
    messages: List[Dict[str, Any]]


@app.post("/memory/save", summary="Save chat history")
async def save_memory(request: SaveRequest) -> Dict[str, str]:
    """Persist messages for a given session.

    If a record for the session already exists it will be overwritten.
    """
    memory_manager.save(request.session_id, request.messages)
    return {"status": "success"}


@app.get("/memory/load", summary="Load chat history")
async def load_memory(session_id: str) -> Dict[str, Any]:
    """Retrieve previously stored messages for a session.

    Returns a 404 error if the session cannot be found.
    """
    messages = memory_manager.load(session_id)
    if messages is None:
        raise HTTPException(status_code=404, detail="Session not found")
    return {"session_id": session_id, "messages": messages}


# Demonstration runnable: simple echo service.  Clients can call
# /echo/invoke with a JSON body like {"input": "Hello"} and receive
# "echo: Hello" in response.  This shows how you can combine custom
# endpoints with LangServe runnables in a single server.
if add_routes is not None and RunnableLambda is not None:
    def echo_fn(text: str) -> str:
        return f"echo: {text}"

    echo_runnable = RunnableLambda(lambda text: echo_fn(text))
    # Mount the runnable at /echo.  LangServe will automatically
    # create /echo/invoke, /echo/stream and other endpoints.
    add_routes(app, echo_runnable, path="/echo")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)