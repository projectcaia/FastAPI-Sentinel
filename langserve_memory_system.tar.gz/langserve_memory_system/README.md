# LangServe Memory Server

This project implements a simple REST API for saving and loading
conversation memory, tailored for applications built with
LangChain, LangServe and LangSmith.  The server supports either
SQLite or Chroma as the underlying storage engine and comes with
ready‑made configuration via environment variables.

While the memory endpoints are bespoke, the project also demonstrates
how to mount a LangChain runnable using LangServe, providing a basis
for building richer agent endpoints alongside your own routes.

## Features

* **Backend flexibility** – Choose between a local SQLite file or a
  persistent Chroma collection for storing chat histories.
* **FastAPI & LangServe** – Implements memory routes manually and uses
  LangServe to expose additional runnables as REST endpoints.
* **LangSmith integration** – Configure your API key and enable
  tracing via environment variables; all downstream LangChain
  operations will emit traces to your LangSmith dashboard.
* **Configurable via `.env`** – Control backend selection, database
  paths and API keys without touching the code.

## Installation

1. Clone or download this repository and change into the
   `langserve_memory_system` directory.
2. Create and activate a Python virtual environment (optional but
   recommended).
3. Install the dependencies:

   ```bash
   pip install -r requirements.txt
   ```

## Configuration

Environment variables are read from a `.env` file in the project root.
Copy the provided `.env.example` and fill in your own values:

```bash
cp .env.example .env
```

Key settings include:

| Variable | Description |
|---------|-------------|
| `MEMORY_BACKEND` | Choose `sqlite` (default) or `chroma`. |
| `SQLITE_DB_PATH` | Path to the SQLite database file when using the sqlite backend. |
| `CHROMA_PERSIST_DIRECTORY` | Directory for Chroma persistence when using the chroma backend. |
| `LANGSMITH_API_KEY` | API key for your LangSmith account. |
| `LANGSMITH_TRACING` | Set to `true` to enable tracing. |
| `LANGCHAIN_PROJECT` | Optional name for grouping traces. |
| `OPENAI_API_KEY` | API key for your LLM provider (not used directly by the memory server). |

## Running the Server

After configuring your environment variables, start the FastAPI app
using Uvicorn:

```bash
uvicorn server:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`.  Swagger UI
documentation is automatically generated and can be viewed at
`http://localhost:8000/docs`.

### Memory Endpoints

* **POST `/memory/save`** – Persist a list of messages for a given
  `session_id`.  The request body should be JSON with the following
  structure:

  ```json
  {
    "session_id": "chat-123",
    "messages": [
      {"role": "human", "content": "Hi there"},
      {"role": "ai", "content": "Hello!"}
    ]
  }
  ```

  The server will respond with `{ "status": "success" }` on
  completion.

* **GET `/memory/load`** – Retrieve messages for a particular
  session.  Pass the `session_id` as a query parameter, e.g.:

  ```http
  GET /memory/load?session_id=chat-123
  ```

  If the session exists, the response will be of the form:

  ```json
  {
    "session_id": "chat-123",
    "messages": [
      {"role": "human", "content": "Hi there"},
      {"role": "ai", "content": "Hello!"}
    ]
  }
  ```

  If the session cannot be found the API returns a 404 status code.

### Echo Runnable

An example LangServe runnable is mounted at `/echo`.  You can test
this by sending a POST request to `/echo/invoke` with a JSON body
containing an `input` field:

```bash
curl -X POST http://localhost:8000/echo/invoke \
     -H "Content-Type: application/json" \
     -d '{"input": "hello"}'
```

The response will be:

```json
{"output": "echo: hello"}
```

This demonstrates how you can combine custom API endpoints with
LangServe’s automatic route generation for LangChain runnables.

## Notes

* This project is a template and does not include authentication or
  rate limiting.  Consider adding appropriate security measures
  before deploying to production.
* The Chroma backend uses the collection name `memories` and stores
  JSON serialisations of your messages.  If you plan to use semantic
  search or embeddings, extend the `MemoryManager` accordingly.

## Troubleshooting

If you encounter `ImportError` exceptions when using the Chroma
backend, ensure that the `chromadb` package is installed and that
``MEMORY_BACKEND=chroma`` is correctly set in your `.env` file.  For
LangServe features to work you must install the package with the
`server` extra as shown in `requirements.txt`.